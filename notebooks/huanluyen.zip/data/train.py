"""Huấn luyện: chuẩn hóa -> PCA -> tự chọn K -> fit K-Means -> lưu mô hình."""
import joblib
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans

from auto_k import find_optimal_k, plot_k_selection

DATA_PATH = "Mall_Customers_Cleaned.csv"
FEATURES = ["Age", "Annual Income (k$)", "Spending Score (1-100)"]
RANDOM_STATE = 42

df = pd.read_csv(DATA_PATH)
X = df[FEATURES]

# 1) Tiền xử lý để tìm K
prep = Pipeline([
    ("scaler", StandardScaler()),
    ("pca", PCA(n_components=2, random_state=RANDOM_STATE)),
])
X_pca = prep.fit_transform(X)

# 2) Tự chọn K
best_k, info = find_optimal_k(X_pca)
print("K được chọn:", best_k)
plot_k_selection(info, best_k, "k_selection.png")

# 3) Huấn luyện mô hình cuối cùng với K đã chọn
model = Pipeline([
    ("scaler", StandardScaler()),
    ("pca", PCA(n_components=2, random_state=RANDOM_STATE)),
    ("kmeans", KMeans(n_clusters=best_k, n_init=10, random_state=RANDOM_STATE)),
])
model.fit(X)

# 4) Lưu mô hình (predict.py sẽ đọc file này)
joblib.dump(model, "kmeans_pipeline.joblib")

# 5) Xem kết quả: mỗi cụm có đặc điểm gì
df["Cluster"] = model.predict(X)
df.to_csv("Mall_Customers_clustered.csv", index=False)
print(df.groupby("Cluster")[FEATURES].mean().round(1))
print(df["Cluster"].value_counts().sort_index())